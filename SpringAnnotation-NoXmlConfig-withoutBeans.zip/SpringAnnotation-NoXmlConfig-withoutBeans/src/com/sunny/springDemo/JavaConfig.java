package com.sunny.springDemo;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

// Add Configuration
@Configuration
@ComponentScan("com.sunny.springDemo") // Add component scan as we do in xml config
public class JavaConfig {
}