package com.sunny.springDemo;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.stereotype.Component;

@Component("thatSillyCoach") //If we gave name then this will be used for getting bean, else camel case name will be used
public class TennisCoach implements Coach {

	FortuneService fortuneService;
	
	//define default constructor
	public TennisCoach() {
		System.out.println("default constructor");
	}
	
	/**
	 * @PostConstruct and @PreDestroy can have any return type but we can't see the return value so its better to use void
	 * @PostConstruct and @PreDestroy can have any access modifier(Public, private, protected)
	 */
	
	//Define my init method
	@PostConstruct
	public void doMyStartupStuff() {
		System.out.println("started");
	}
	
	//Define my destroy method, will be called before bean gets destroyed
	/**
	 * In case of prototype scope, the spring doesn't call @PreDestroy method.
	 * In this case, configured destruction life cycle callbacks are not called so we have to clean up prototype objects.
	 * OR we can explicitly call the destroy method with custom coding using CUSTOM BEAN PROCESSOR which will keep tracking on shut down and 
	 * destroy it via implementing DisposableBean interface
	 */
	@PreDestroy
	public void doMyCleanupStuff() {
		System.out.println("destroy");
	}
	
	@Override
	public String getDailyWorkout() {
		return "Practice your backhand volley";
	}

	@Override
	public String getDailyFortune() {
		return fortuneService.getFortune();
	}

}