package com.sunny.hibernate.demo.CRUD;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import com.sunny.hibernate.mapping.entityClass.StudentEntity;

public class QueryStudentDemo {

	public static void main(String[] args) {

		// create session factory
		SessionFactory factory = new Configuration()
								.configure("hibernate.cfg.xml")
								.addAnnotatedClass(StudentEntity.class)
								.buildSessionFactory();
		// create session
		Session session = factory.getCurrentSession();
		try {
			
			// start a transaction
			session.beginTransaction();
			
			// query students, while using this, we have to use java class name instead of actual DB name.
			List<StudentEntity> theStudents = session.createQuery("from StudentEntity").getResultList();
			
			// display the students
			displayStudents(theStudents);
			
			// commit transaction
			session.getTransaction().commit();
			
			System.out.println("Done!");
		}
		finally {
			session.close();
			factory.close();
		}
	}

	private static void displayStudents(List<StudentEntity> theStudents) {
		for (StudentEntity tempStudent : theStudents) {
			System.out.println(tempStudent);
		}
	}

}