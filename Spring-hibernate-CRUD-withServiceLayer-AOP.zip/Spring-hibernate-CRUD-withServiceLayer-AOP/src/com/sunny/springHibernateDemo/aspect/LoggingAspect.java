package com.sunny.springHibernateDemo.aspect;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class LoggingAspect {
	
	@Pointcut(value = "execution(public void com.sunny.springHibernateDemo.DAO.StudentDAO_Impl.saveStudent(com.sunny.springHibernateDemo.entity.StudentEntity))")
	public void saveStudentPC() {}
	
	@Before(value = "saveStudentPC()")
	public void beforeAddingStudent()
	{
		System.out.println("inside before adding student");
	}
}