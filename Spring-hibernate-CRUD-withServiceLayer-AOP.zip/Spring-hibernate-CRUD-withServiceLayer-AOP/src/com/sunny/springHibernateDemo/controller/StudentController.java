package com.sunny.springHibernateDemo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.sunny.springHibernateDemo.entity.StudentEntity;
import com.sunny.springHibernateDemo.service.StudentService;

@Controller
@RequestMapping("/student")
public class StudentController {
	
	@Autowired
	private StudentService service;
	
	 @GetMapping("/showStudents") // If we want to restrict request type to GET only then instead of @RequestMapping we can use @GetMapping
	// @RequestMapping("/showStudents")
	public String showStudents(Model model) {
		
		// Get students from service
		List<StudentEntity> students = service.getStudents();
		
		model.addAttribute("studentListFromDAO", students);
		
		return "student-list";
	}
	 
	 @GetMapping("/showFormForAdd")
	 public String showFormForAdd(Model model)
	 {
		 // Add attibute to model to bind form data
		 model.addAttribute("studentModel", new StudentEntity());
		 return "add-student";
	 }
	 
	 @PostMapping("/saveStudent")
	 public String processStudentToAdd(@ModelAttribute("studentModel") StudentEntity studentEntity)
	 {
		 service.saveStudent(studentEntity);
		return "redirect:/student/showStudents"; 
	 }
	 
	 @GetMapping("/updateStudent")
	 // stu_id is the same variable we used in jsp file to append in c:url paramter in student list
	 public String processStudentToUpdate(@RequestParam("stu_id") int pk, Model model)
	 {
		 
		 System.out.println("Fetching student for stu_id : " + pk);
		 // Get the student using id
		 StudentEntity student = service.getStudent(pk);
		 
		 System.out.println("Student is as : "+ student);
		 
		 // use same attribute which is being used in form to create as we are using same form
		 model.addAttribute("studentModel", student);
		 
		 return "add-student";
	 }
	 
	 @GetMapping("/deleteStudent")
	 // stu_id is the same variable we used in jsp file to append in c:url paramter in student list
	 public String processStudentToDelete(@RequestParam("stu_id") int pk)
	 {
		 System.out.println("Fetching student for stu_id : " + pk);
		 // Get the student using id
		 
		 service.deleteStudent(pk);
		 
		 return "redirect:/student/showStudents";
	 }
	 
	 @GetMapping("/search")
	 public String performSearchOnStudent(@RequestParam("theSearchName") String theSearchName, Model model)
	 {
		 List<StudentEntity> students = service.search(theSearchName);
		 
		 // use same attribute which is being used in form to create as we are using same form
		 model.addAttribute("studentListFromDAO", students);
		 
		 return "student-list";
	 }
	 
	 @GetMapping("/clearSearch")
	 public String clearSearchOnStudent(Model model)
	 {
		 List<StudentEntity> students = service.getStudents();
		 
		 // use same attribute which is being used in form to create as we are using same form
		 model.addAttribute("studentListFromDAO", students);
		 
		 return "redirect:/student/showStudents";
	 }
} 