package com.spring.rest.exceptionHandling;

public class CreateStudentNotFoundException extends RuntimeException{

	public CreateStudentNotFoundException(String message) {
		super(message);
	}
}
