package com.spring.rest.configuration;

import org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer;

public class SpringMvcDispacherServletInitializer extends AbstractAnnotationConfigDispatcherServletInitializer{

	@Override
	protected Class<?>[] getRootConfigClasses() {
		return null;
	}

	// Pass the Config file
	@Override
	protected Class<?>[] getServletConfigClasses() {
		return new Class[] { SpringRest_Config.class };
	}

	@Override
	protected String[] getServletMappings() {
		// Pass the root path like '/'
		return new String[] { "/" };
	}
}