package com.spring.rest.controller;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.spring.rest.entity.Student;
import com.spring.rest.exceptionHandling.CreateStudentNotFoundException;

@RestController
@RequestMapping(value = "/Spring")
public class SpringRestController {
	
	private List<Student> students;
	
	@PostConstruct
	private void loadData()
	{
		students = new ArrayList<Student>();
		students.add(new Student("Sunny", "Mittal"));
		students.add(new Student("Vikram", "Sharma"));
		students.add(new Student("Naman", "Handa"));
	}

	@GetMapping("/hello")
	private String getHelloPage() {
		return "Hello";
	}
	
	@GetMapping("/students")
	private List<Student> getStudents() {
		return students;
	}
	
	@GetMapping("/students/{id}")
	private Student getStudent(@PathVariable int id) {
		
		if(id >= students.size() || id < 0)
			throw new CreateStudentNotFoundException("Student Not Found for id "+ id);
		
		return students.get(id);
	}
	
}