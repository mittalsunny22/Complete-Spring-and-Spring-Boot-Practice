package com.sunny.springdemo.service;

import java.util.List;

import com.sunny.springdemo.model.StudentEntity;

public interface StudentService {

	public List<StudentEntity> getStudents();

	public void saveStudent(StudentEntity theStudent);

	public StudentEntity getStudent(int theId);

	public void deleteStudent(int theId);
	
}
