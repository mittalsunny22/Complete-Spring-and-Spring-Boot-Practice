package com.sunny.springdemo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.sunny.springdemo.model.StudentEntity;
import com.sunny.springdemo.service.StudentService;

@Controller
public class StudentController {

	// need to inject our student service
	@Autowired
	private StudentService studentService;
	
	@GetMapping("/students") 
	public String listStudents(Model theModel) {
		
		// get students from the service
		List<StudentEntity> theStudents = studentService.getStudents();
				
		// add the students to the model
		theModel.addAttribute("students", theStudents);
		
		return "list-students";
	}
	
	@GetMapping("/showFormForAdd")
	public String showFormForAdd(Model theModel) {
		
		// create model attribute to bind form data
		StudentEntity theStudent = new StudentEntity();
		
		theModel.addAttribute("student", theStudent);
		
		return "student-form";
	}
	
	@PostMapping("/saveStudent")
	public String saveStudent(@ModelAttribute("student") StudentEntity theStudent) {
		
		// save the student using our service
		studentService.saveStudent(theStudent);	
		
		return "redirect:/students";
	}
	
	@GetMapping("/updateStudent")
	public String showFormForUpdate(@RequestParam("stu_id") int theId, Model model) {
		
		// get the student from our service
		StudentEntity theStudent = studentService.getStudent(theId);
		
		// set student as a model attribute to pre-populate the form
		model.addAttribute("student", theStudent);
		
		// send over to our form		 
		return "student-form";
	}
	
	@GetMapping("/deleteStudent")
	public String deleteStudent(@RequestParam("stu_id") int theId) {
		
		// delete the student
		studentService.deleteStudent(theId);
		
		return "redirect:/students";
	}
}