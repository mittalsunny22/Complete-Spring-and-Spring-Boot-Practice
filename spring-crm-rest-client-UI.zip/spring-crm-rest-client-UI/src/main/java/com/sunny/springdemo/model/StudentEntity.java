package com.sunny.springdemo.model;

public class StudentEntity {

	private int id_PK;
	
	private String firstName;
	
	private String lastName;
	
	private String email;
	
	public StudentEntity() {
		
	}

	public int getId_PK() {
		return id_PK;
	}

	public void setId_PK(int id) {
		this.id_PK = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Override
	public String toString() {
		return "Student [id=" + id_PK + ", firstName=" + firstName + ", lastName=" + lastName + ", email=" + email + "]";
	}
		
}





