CREATE TABLE users (
    username VARCHAR(50) NOT NULL PRIMARY KEY,
    password VARCHAR(50) NOT NULL,
    enabled TINYINT(2) NOT NULL
); 

CREATE TABLE authorities (
    username VARCHAR(50) NOT NULL,
    authority VARCHAR(50) NOT NULL,
    unique key authorities_idx (username, authority),
    constraint authorities_ibfdx foreign key (username) references users (username)
);

Insert into users values 
	('sunny','{noop}sunny',1),
	('vikram','{noop}vikram',1),
	('naman','{noop}naman',1);
        
Select * from users;

Insert into authorities values 
	('sunny','ROLE_EMPLOYEE'),
    ('sunny','ROLE_MANAGER'),
	('vikram','ROLE_EMPLOYEE'),
    ('vikram','ROLE_ADMIN'),
	('naman','ROLE_EMPLOYEE');
    
Select username, authority from authorities;