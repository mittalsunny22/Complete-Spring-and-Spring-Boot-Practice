package com.springBoot.rest.crudSpringBootDemo.DAO;

import java.util.List; 
import javax.persistence.Query;
import javax.persistence.EntityManager;
import org.springframework.stereotype.Repository;
import org.springframework.beans.factory.annotation.Autowired;
import com.springBoot.rest.crudSpringBootDemo.Entity.Employee;

@Repository
public class EmployeeDaoImpl implements EmployeeDao{

	@Autowired
	private EntityManager entityManager;
	
	@Override
	public List<Employee> findAll() {
		
		Query createQuery = entityManager.createQuery("from Employee");
		return createQuery.getResultList();
	}

	@Override
	public Employee findEmployee(int id) {
		
		Employee employee = entityManager.find(Employee.class, id);
		return employee;
	}

	@Override
	public void saveEmployee(Employee employee) {
		
		Employee dbEmployee = entityManager.merge(employee);
		employee.setId(dbEmployee.getId());
	}

	@Override
	public void deleteEmployee(int id) {
		
		Query createQuery = entityManager.createQuery("delete from Employee where id="+ id);
		createQuery.executeUpdate();
	}
}