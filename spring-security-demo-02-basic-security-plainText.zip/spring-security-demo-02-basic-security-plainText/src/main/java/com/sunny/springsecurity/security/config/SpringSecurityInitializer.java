package com.sunny.springsecurity.security.config;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

public class SpringSecurityInitializer extends AbstractSecurityWebApplicationInitializer{

	// We just need to extend 'AbstractSecurityWebApplicationInitializer' class in order to initialize spring security in Web application
}