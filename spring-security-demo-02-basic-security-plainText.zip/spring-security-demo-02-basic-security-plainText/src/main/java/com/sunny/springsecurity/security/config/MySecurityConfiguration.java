package com.sunny.springsecurity.security.config;

import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

@EnableWebSecurity
@Configuration
public class MySecurityConfiguration extends WebSecurityConfigurerAdapter{
	
	@Autowired
	public DataSource myDataSource; // this is prepared in Project configuration file

	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		auth.jdbcAuthentication().dataSource(myDataSource);
	}
	
	// Override below method if we want to create our own login form instead of default one
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		
/*		http.authorizeRequests()
			.anyRequest().authenticated() // This will handle for all requests needs to parse if user is authenticated
		.and()
		.formLogin()
			.loginPage("/showMyLoginPage") // create controller mapping for this
			.loginProcessingUrl("/authenticateUser") // This will be send in login form as action
			.permitAll()
		.and()
			.logout().permitAll(); */
		
		http.authorizeRequests()
		// We will now use below code as we want to restrict pages based on role
			.antMatchers("/").hasRole("EMPLOYEE")
			.antMatchers("/leaders/**").hasRole("MANAGER")
			.antMatchers("/System/**").hasRole("ADMIN")
		.and()
		.formLogin()
			.loginPage("/showMyLoginPage") // create controller mapping for this
			.loginProcessingUrl("/authenticateUser") // This will be send in login form as action
			.permitAll()
		.and()
		.logout().permitAll()
		// Below part is to handle restricted pages
		.and()
		.exceptionHandling()
		.accessDeniedPage("/access-denied"); // create controller mapping for this 
	}
}