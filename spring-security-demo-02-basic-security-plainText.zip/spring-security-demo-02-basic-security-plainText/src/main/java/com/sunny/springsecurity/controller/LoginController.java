package com.sunny.springsecurity.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class LoginController {
	
	@GetMapping("/showMyLoginPage")
	private String showLoginForm()
	{
		return "custom-loginForm";
	}
	
	@GetMapping("/leaders")
	private String getLeadersPage()
	{
		return "leaders";
	}
	
	@GetMapping("/System")
	private String getSystemPage()
	{
		return "system";
	}
	
	@GetMapping("/access-denied")
	private String getAccessDeniedPage()
	{
		return "access-denied";
	}
}