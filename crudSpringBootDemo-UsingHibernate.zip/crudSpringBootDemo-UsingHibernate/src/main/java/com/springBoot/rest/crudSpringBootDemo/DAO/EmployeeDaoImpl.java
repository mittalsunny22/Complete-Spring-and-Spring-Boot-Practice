package com.springBoot.rest.crudSpringBootDemo.DAO;

import java.util.List;
import javax.persistence.EntityManager;
import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.springBoot.rest.crudSpringBootDemo.Entity.Employee;

@Repository
public class EmployeeDaoImpl implements EmployeeDao{

	@Autowired
	private EntityManager entityManager;
	
	@Override
	public List<Employee> findAll() {
		
		// get current hibernate session
		Session session = entityManager.unwrap(Session.class);
	
		List<Employee> resultList = session.createQuery("from Employee").getResultList();
		
		return resultList;
	}

	@Override
	public Employee findEmployee(int id) {
		
		Session session = entityManager.unwrap(Session.class);
		Employee employee = session.get(Employee.class, id);
		return employee;
	}

	@Override
	public void saveEmployee(Employee employee) {
		
		Session session = entityManager.unwrap(Session.class);
		session.saveOrUpdate(employee);
	}

	@Override
	public void deleteEmployee(int id) {
		
		Session session = entityManager.unwrap(Session.class);
		Query createQuery = session.createQuery("delete from Employee where id="+ id);
		createQuery.executeUpdate();
	}
}