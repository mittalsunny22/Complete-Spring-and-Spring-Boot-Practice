package com.sunny.springdemo.controller;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sunny.springdemo.entity.StudentEntity;
import com.sunny.springdemo.exceptionHandling.StudentNotFoundException;
import com.sunny.springdemo.service.StudentService;

@RestController
@RequestMapping("/api")
public class StudentController {

	@Autowired
	private StudentService studentService;

	@GetMapping("/students/{stu_id}")
	private StudentEntity getStudent(@PathVariable int stu_id) {

		StudentEntity student = studentService.getStudent(stu_id);
		
		if (student == null)
			throw new StudentNotFoundException("Student Not Found with id " + stu_id);
		else
			return student;
	}

	@GetMapping("/students")
	private List<StudentEntity> getStudents() {
		
		List<StudentEntity> students = studentService.getStudents();

		if (students.isEmpty())
			throw new StudentNotFoundException("There is No student available");
		else
			return students;
	}

	@PutMapping("/students/{stu_id}")
	private StudentEntity updateStudent(@PathVariable int stu_id, @RequestBody StudentEntity studentEntity) {
		
		StudentEntity student = studentService.getStudent(stu_id);

		if (student == null)
			throw new StudentNotFoundException("Student Not Found with id " + stu_id);
		
		studentEntity.setId_PK(stu_id);
		studentEntity.setModifiedBy(LocalDateTime.now());
		studentService.saveStudent(studentEntity);
		
		return studentEntity;
	}

	@DeleteMapping("/students/{stu_id}")
	private String deleteStudent(@PathVariable int stu_id) {
		
		StudentEntity student = studentService.getStudent(stu_id);

		if (student == null)
			throw new StudentNotFoundException("Student Not Found with id " + stu_id);
		
		studentService.deleteStudent(stu_id);
		
		return "Student with id {" + stu_id + "} has been deleted";
	}

	@PostMapping("/students")
	private StudentEntity createStudent(@RequestBody StudentEntity studentEntity) {
		
		// We passed 0 as pk because the method will call saveOrUpdate based on pk available or not
		studentEntity.setId_PK(0);
		
		//Rest of the fields we can set by passing request body
		/*{
	        "firstName": "ER.Sunny",
	        "lastName": "Mittal",
	        "email": "sunny.mittal@hcl.com"
		}*/
		studentEntity.setCreatedBy(LocalDateTime.now());
		studentService.saveStudent(studentEntity);
		
		return studentEntity;
	}
}