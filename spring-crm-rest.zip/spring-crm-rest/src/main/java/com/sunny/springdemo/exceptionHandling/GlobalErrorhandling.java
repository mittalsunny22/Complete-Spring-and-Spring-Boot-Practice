package com.sunny.springdemo.exceptionHandling;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

// This will be used globally in whole project
@ControllerAdvice
public class GlobalErrorhandling {

	@ExceptionHandler
	public ResponseEntity<ExceptionHandlerForStudent> handleExceptionForStudent(StudentNotFoundException exception)
	{
		ExceptionHandlerForStudent handler = new ExceptionHandlerForStudent(HttpStatus.NOT_FOUND.value(), exception.getMessage(), System.currentTimeMillis());
		return new ResponseEntity<ExceptionHandlerForStudent>(handler, HttpStatus.valueOf(handler.getStatusCode()));
	}
	
	@ExceptionHandler
	public ResponseEntity<ExceptionHandlerForStudent> handleExceptionForAllExceptions(Exception exception)
	{
		ExceptionHandlerForStudent handler = new ExceptionHandlerForStudent(HttpStatus.BAD_REQUEST.value(), exception.getMessage(), System.currentTimeMillis());
		return new ResponseEntity<ExceptionHandlerForStudent>(handler, HttpStatus.valueOf(handler.getStatusCode()));
	}
}