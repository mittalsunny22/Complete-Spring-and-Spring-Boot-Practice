package com.sunny.springdemo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.sunny.springdemo.dao.StudentDAO;
import com.sunny.springdemo.entity.StudentEntity;

@Service
public class StudentService_Impl implements StudentService{

	@Autowired
	private StudentDAO studentDAO;
	
	@Override
	@Transactional
	// @Transactional annotation will help us to not to write beginTransaction, save or other stuff
	public List<StudentEntity> getStudents() {
		return studentDAO.getStudents();
	}

	@Override
	@Transactional
	public void saveStudent(StudentEntity entity) {
		studentDAO.saveStudent(entity);
	}
	
	@Override
	@Transactional
	public StudentEntity getStudent(int pk){
		return studentDAO.getStudent(pk);
	}

	@Override
	@Transactional
	public void deleteStudent(int pk) {
		studentDAO.deleteStudent(pk);
	}

	@Override
	@Transactional
	public List<StudentEntity> search(String theSearchName) {
		return studentDAO.search(theSearchName);
	}
}