package com.sunny.springdemo.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.sunny.springdemo.entity.StudentEntity;

//Once we are done with DAO Impl, then we have to inject this 'StudentDAO' to Controller using @autowired

// This is used with DAO which handles all CRUD operations. This is sub class of @Component so holds all features
@Repository
public class StudentDAO_Impl implements StudentDAO{

	// Need to inject the session factory so that we can make crud operations here 
	@Autowired
	private SessionFactory sessionFactory; // this variable should be same as defined in bean as id in 'spring-mvc-crud-servlet.xml'
	
	@Override
	public List<StudentEntity> getStudents() {
		
		// get current hibernate session
		Session currentSession = sessionFactory.getCurrentSession();
		
		List<StudentEntity> resultList = currentSession.createQuery("from StudentEntity").getResultList();
		
		return resultList;
	}

	@Override
	public void saveStudent(StudentEntity entity) {
		
		Session currentSession = sessionFactory.getCurrentSession();
		
		System.out.println("PK is " + entity.getId_PK());
		
		currentSession.saveOrUpdate(entity);
	}

	@Override
	public StudentEntity getStudent(int pk) {
		
		Session currentSession = sessionFactory.getCurrentSession();
		
		StudentEntity entity = currentSession.get(StudentEntity.class,pk);
		
		System.out.println("Fetched Student is : " + entity);
		
		return entity;
	}

	@Override
	public void deleteStudent(int pk) {
		
		Session currentSession = sessionFactory.getCurrentSession();
		
		StudentEntity studentEntity = currentSession.get(StudentEntity.class, pk);
		
		currentSession.delete(studentEntity);
		
		System.out.println("Student Has been deleted");
	}

	@Override
	public List<StudentEntity> search(String theSearchName) {
		
		Session currentSession = sessionFactory.getCurrentSession();
		
		List<StudentEntity> resultList = currentSession
				.createQuery("from StudentEntity where firstName like '%"+theSearchName + "%' OR lastName like '%"+theSearchName + "%'")
				.getResultList();
		
		System.out.println("Filter Searched List size is "+ resultList.size());
		
		return resultList;
	}
}