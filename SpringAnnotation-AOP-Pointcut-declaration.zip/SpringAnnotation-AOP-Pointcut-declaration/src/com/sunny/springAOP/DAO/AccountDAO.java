package com.sunny.springAOP.DAO;

import org.springframework.stereotype.Component;

/*
 * This is the Target object
 */
@Component(value = "AccountDAO_Bean")
public class AccountDAO {

	public void addAccount(String name)
	{
		System.out.println(getClass() + " running code in addAccount()");
	}
	
	public void setName()
	{
		System.out.println(getClass() + " running code in setName()");	
	}
}
