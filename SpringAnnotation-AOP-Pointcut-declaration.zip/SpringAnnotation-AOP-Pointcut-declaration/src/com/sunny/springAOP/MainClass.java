package com.sunny.springAOP;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.sunny.springAOP.DAO.AccountDAO;

public class MainClass {

	public static void main(String[] args) {
		
		AnnotationConfigApplicationContext applicationContext = new AnnotationConfigApplicationContext(SpringConfig.class);
		
		AccountDAO bean = applicationContext.getBean("AccountDAO_Bean", AccountDAO.class);
		
		bean.addAccount("test");
		bean.setName();
		applicationContext.close();
		
		System.out.println("Done");
	}
	
}
