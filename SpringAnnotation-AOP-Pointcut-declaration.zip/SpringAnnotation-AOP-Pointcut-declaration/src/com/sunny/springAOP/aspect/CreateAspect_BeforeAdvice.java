package com.sunny.springAOP.aspect;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Component
@Aspect
@Order(value = 1) // In case we have multiple aspects and we want to provide order, if one aspect then we don't need @Order
public class CreateAspect_BeforeAdvice {

	@Before(value = "commonExpression() || !commonExpressionToExcludeSetterStartingMethod()")
	public void verifyUserBeforeAddingAccount(JoinPoint joinPoint)
	{
		System.out.println(getClass() + " verifying user before adding account"); 
		
		MethodSignature methodSignature = (MethodSignature) joinPoint.getSignature();
		
		String[] parameterNames = methodSignature.getParameterNames();

		System.out.println("Below are the parameters defined in "+methodSignature);

		for (String parameter : parameterNames) {
			System.out.println("\t" + parameter);
		}
		
		System.out.println("Below are the values defined in parameter while calling");
		
		// Values passed
		Object[] args = joinPoint.getArgs();
		
		for (Object object : args) {
			System.out.println("\t" + object);
		}
		
		System.out.println("**************");
	}

	@Pointcut("execution(public void addAccount(..))")
	public void commonExpression() {}
	
	@Pointcut("execution(public void set*())")
	public void commonExpressionToExcludeSetterStartingMethod() {}
}