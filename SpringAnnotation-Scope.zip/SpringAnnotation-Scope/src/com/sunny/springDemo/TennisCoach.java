package com.sunny.springDemo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("thatSillyCoach") //If we gave name then this will be used for getting bean, else camel case name will be used
@Scope("prototype") //Can be Singleton
public class TennisCoach implements Coach {

	FortuneService fortuneService;
	
	// Define Setter Method , use any name just use @autowired
	@Autowired
	public void setFortuneServices(FortuneService theFortuneService) {
		fortuneService =theFortuneService;
	}
	
	@Override
	public String getDailyWorkout() {
		return "Practice your backhand volley";
	}

	@Override
	public String getDailyFortune() {
		return fortuneService.getFortune();
	}

}