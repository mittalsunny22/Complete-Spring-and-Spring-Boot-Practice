package com.sunny.springAOP.aspect;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class CreateAspect_BeforeAdvice {

	/* If we want to call this for any addAccount() method then below code is fine else
		we have to give proper class and package path along with method name
		Eg: execution(public void com.sunny.springAOP.DAO.AccountDAO.addAccount())
		Similarly we can use wildcards as well. For Eg: execution(public void add*())
		*/
	@Before(value = "execution(public void addAccount())")
	public void verifyUserBeforeAddingAccount()
	{
		System.out.println(getClass() + " verifying user before adding account");
	}

	// Also, if we want to apply same expression on multiple advices, then either we can copy same method and use @After
	// But that will be not okay because if we have to change in future then we have to change at every place
	// we can create pointcut and use that point cut instead of expression
	
	/*
	 * Way to create pointcut
	 * Step1
	 */
	@Pointcut("execution(public void addAccount())")
	public void commonExpression() {}
	
	/*
	 * Step2, now use that commonExpression() as expression and pass it to any advice. For Eg: 
	 * 	@Before(value = "commonExpression()")
	 */
}