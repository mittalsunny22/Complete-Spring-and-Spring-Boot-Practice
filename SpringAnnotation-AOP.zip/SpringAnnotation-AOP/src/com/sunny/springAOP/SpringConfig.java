package com.sunny.springAOP;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

@Configuration
@EnableAspectJAutoProxy //Adding code to enable AspectJ proxy which means enabling AOP
@ComponentScan("com.sunny.springAOP")
public class SpringConfig {

	
}
