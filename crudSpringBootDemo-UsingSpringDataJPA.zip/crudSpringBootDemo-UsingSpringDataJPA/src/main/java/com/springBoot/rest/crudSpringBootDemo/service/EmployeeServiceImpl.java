package com.springBoot.rest.crudSpringBootDemo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springBoot.rest.crudSpringBootDemo.DAO.EmployeeDaoRepository;
import com.springBoot.rest.crudSpringBootDemo.Entity.Employee;

@Service
public class EmployeeServiceImpl implements EmployeeService{

	@Autowired
	private EmployeeDaoRepository employeeDao;
	
	@Override
	public List<Employee> findAll() {
		return employeeDao.findAll();
	}

	@Override
	public Employee findEmployee(int id) {
		
		Optional<Employee> findById = employeeDao.findById(id);
		
		if(findById.isPresent())
			return findById.get();
 
		return null;
	}

	@Override
	public void saveEmployee(Employee employee) {
		employeeDao.save(employee);
	}

	@Override
	public void deleteEmployee(int id) {
		employeeDao.deleteById(id);
	}
}