package com.springBoot.thymeleafDemo.controller;

import java.util.Date;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HelloController {
	
	@GetMapping("/hello")
	public String getFirstPage()
	{
		// As we have thymeleaf dependency in pom so by default code will look for 'hello-world.html' file inside Templates folder
		return "hello-world"; 
	}
	
	@GetMapping("/date")
	public String getCurrentDate(Model model)
	{
		// As we have thymeleaf dependency in pom so by default code will look for 'hello-world.html' file inside Templates folder
		model.addAttribute("dateModel", new Date());
		return "date-page"; 
	}

}