package com.sunny.springHibernateDemo.service;

import java.util.List;

import com.sunny.springHibernateDemo.entity.StudentEntity;

public interface StudentService {
	
	public List<StudentEntity> getStudents();
	
	public void saveStudent(StudentEntity entity);
	
	public StudentEntity getStudent(int pk);

	public void deleteStudent(int pk);

	public List<StudentEntity> search(String theSearchName);
}