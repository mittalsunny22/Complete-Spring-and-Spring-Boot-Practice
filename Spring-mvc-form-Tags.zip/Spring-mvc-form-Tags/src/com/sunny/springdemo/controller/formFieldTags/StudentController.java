package com.sunny.springdemo.controller.formFieldTags;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/student")
public class StudentController {

	//controller method to show form for Student
	@RequestMapping("/showForm")
	public String showForm(Model model)
	{
		// add Student object to model. Same 'studentModelAttr' has to be pass in form modelAttribute
		model.addAttribute("studentModelAttr", new StudentBean());
		return "student-form";
	}
	
	@RequestMapping("/processForm")
	// with 'studentModelAttr' we can print all values in JSP final page
	public String processFormForStudent(@ModelAttribute("studentModelAttr") StudentBean studentBean)
	{
		// log the student data here
		//System.out.println("First Name in controller is : " + studentBean.getFirstName());
		//System.out.println("last Name in controller is : " + studentBean.getLastName());
		return "student-confirmation-page";
	}
	
	/*
	 *  Below method is to validate the fields using hibernate validator
	 *  1. we have to use @valid before to @modelAttribute
	 *  2. we have to add BindingResult parameter as Spring will store validation results in BindingResult object
	 */
	@RequestMapping("/processFormToValidate")
	// with 'studentModelAttr' we can print all values in JSP final page
	public String processFormForStudentToValidate(@Valid @ModelAttribute("studentModelAttr") StudentBean studentBean, BindingResult bindingResult)
	{
		// log the student data here
		// System.out.println("First Name in controller is : " + studentBean.getFirstName());
		// System.out.println("last Name in controller is : " + studentBean.getLastName());
		// System.out.println("Does Binding Result has errors : " + bindingResult.hasErrors());
		
		if(bindingResult.hasFieldErrors())
			return "student-form"; // return same page so that it can show errors
		else
		return "student-confirmation-page";
	}
}