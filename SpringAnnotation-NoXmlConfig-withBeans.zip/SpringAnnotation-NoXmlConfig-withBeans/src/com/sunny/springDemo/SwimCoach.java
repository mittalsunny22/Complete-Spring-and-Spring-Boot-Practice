package com.sunny.springDemo;

public class SwimCoach implements Coach{
	
	private FortuneService fortuneService;
	
	public SwimCoach(FortuneService thefortuneService) {
		fortuneService = thefortuneService;
	}

	@Override
	public String getDailyWorkout() {
		return "swim 1000 times";
	}

	@Override
	public String getDailyFortune() {
		return fortuneService.getFortune();
	}

}
