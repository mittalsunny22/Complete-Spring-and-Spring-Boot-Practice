package com.sunny.springHibernateDemo.DAO;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.sunny.springHibernateDemo.entity.StudentEntity;

//Once we are done with DAO Impl, then we have to inject this 'StudentDAO' to Controller using @autowired

// This is used with DAO which handles all CRUD operations. This is sub class of @Component so holds all features
@Repository
public class StudentDAO_Impl implements StudentDAO{

	// Need to inject the session factory so that we can make crud operations here 
	@Autowired
	private SessionFactory sessionFactory; // this variable should be same as defined in bean as id in 'spring-mvc-crud-servlet.xml'
	
	@Override
	@Transactional
	// @Transactional annotation will help us to not to write beginTransaction, save or other stuff
	public List<StudentEntity> getStudents() {
		
		// get current hibernate session
		Session currentSession = sessionFactory.getCurrentSession();
		
		List<StudentEntity> resultList = currentSession.createQuery("from StudentEntity").getResultList();
		
		return resultList;
	}
}