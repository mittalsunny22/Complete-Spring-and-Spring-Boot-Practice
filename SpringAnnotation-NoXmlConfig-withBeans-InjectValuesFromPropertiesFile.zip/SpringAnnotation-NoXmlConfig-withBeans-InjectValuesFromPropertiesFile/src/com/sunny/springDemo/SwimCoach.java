package com.sunny.springDemo;

import org.springframework.beans.factory.annotation.Value;

public class SwimCoach implements Coach{
	
	private FortuneService fortuneService;
	
	//Field Level Injection
	@Value("${swim.team}")
	private String teamName;
	
	@Value("${swim.playerName}")
	private String teamPlayer;
	
	@Value("${test}")
	private String teamTest;
	
	public SwimCoach(FortuneService thefortuneService) {
		fortuneService = thefortuneService;
	}

	@Override
	public String getDailyWorkout() {
		return "swim 1000 times";
	}

	@Override
	public String getDailyFortune() {
		return fortuneService.getFortune();
	}

	public String getTeamName() {
		return teamName;
	}

	public String getTeamPlayer() {
		return teamPlayer;
	}

	public String getTeamTest() {
			return teamTest;
	}
}