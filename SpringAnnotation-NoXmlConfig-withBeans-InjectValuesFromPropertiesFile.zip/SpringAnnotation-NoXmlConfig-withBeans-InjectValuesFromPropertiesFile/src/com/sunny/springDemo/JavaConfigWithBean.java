package com.sunny.springDemo;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

// Add Configuration
@Configuration

//Import the property file to get values
@PropertySource("classpath:swim.properties")
public class JavaConfigWithBean {
	
	//Define bean for sad fortune service
	@Bean
	public FortuneService sadFortuneService()
	{
		return new SadFortuneService();
	}
	
	// Defining Bean where swimCoach is bean-id and inject dependency
	@Bean 
	public Coach swimCoach()
	{
		return new SwimCoach(sadFortuneService());
	}
}