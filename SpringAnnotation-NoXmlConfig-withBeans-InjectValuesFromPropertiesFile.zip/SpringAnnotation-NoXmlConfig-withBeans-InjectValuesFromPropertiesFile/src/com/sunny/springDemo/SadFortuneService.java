package com.sunny.springDemo;

public class SadFortuneService implements FortuneService{

	@Override
	public String getFortune() {
		return "My Fortune is from SadFortuneService";
	}

}
