package com.springBoot.rest.crudSpringBootDemo.DAO;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.springBoot.rest.crudSpringBootDemo.Entity.Employee;

// Below Annotation is used when we want to explicitly specify some other name for APIs
//@RepositoryRestResource(path = "employeesNew")
public interface EmployeeDaoRepository extends JpaRepository<Employee, Integer>{

	// No need to add any impl class as well because JPA Repository will have all methods available
}