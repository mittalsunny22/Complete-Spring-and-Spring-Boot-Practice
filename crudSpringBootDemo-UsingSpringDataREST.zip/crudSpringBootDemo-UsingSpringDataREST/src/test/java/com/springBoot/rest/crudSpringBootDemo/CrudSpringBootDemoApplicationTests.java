package com.springBoot.rest.crudSpringBootDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudSpringBootDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
