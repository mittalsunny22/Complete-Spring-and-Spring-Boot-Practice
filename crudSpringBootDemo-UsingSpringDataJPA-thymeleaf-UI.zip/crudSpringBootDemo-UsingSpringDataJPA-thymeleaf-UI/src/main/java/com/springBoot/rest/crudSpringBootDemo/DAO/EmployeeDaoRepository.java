package com.springBoot.rest.crudSpringBootDemo.DAO;

import org.springframework.data.jpa.repository.JpaRepository;

import com.springBoot.rest.crudSpringBootDemo.Entity.Employee;

public interface EmployeeDaoRepository extends JpaRepository<Employee, Integer>{

	// No need to add any impl class as well because JPA Repository will have all methods available
	
}