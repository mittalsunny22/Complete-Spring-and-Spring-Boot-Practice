package com.springBoot.rest.crudSpringBootDemo.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.springBoot.rest.crudSpringBootDemo.Entity.Employee;
import com.springBoot.rest.crudSpringBootDemo.service.EmployeeService;

@Controller
@RequestMapping("/api")
public class RestControllerForEmployee {
	
	@Autowired
	private EmployeeService employeeService;
	
	@GetMapping("/employees")
	public String fetchAllEmployees(Model model)
	{
		List<Employee> findAll = employeeService.findAll();
		
		model.addAttribute("employees_list", findAll);
		
		return "list-employees";
	}
	
	@GetMapping("/showFormToAdd")
	public String showAddForm(Model model)
	{
		model.addAttribute("addEmployee", new Employee());
		
		return "add-employee";
	}
	
	@PostMapping("/save")
	public String saveFormForAddEmployee(@ModelAttribute("addEmployee") Employee employee)
	{
		employeeService.saveEmployee(employee);
		
		return "redirect:/api/employees";
	}
	
	@GetMapping("/showFormToUpdate")
	public String showUpdateForm(@RequestParam("employeeId") int employeeID, Model model)
	{
		Employee findEmployee = employeeService.findEmployee(employeeID);
		
		model.addAttribute("addEmployee", findEmployee);
		
		return "add-employee";
	}
	
	@GetMapping("/delete")
	public String deleteEmployee(@RequestParam("employeeId") int id)
	{
		employeeService.deleteEmployee(id);
		
		return "redirect:/api/employees";
	}
	
	@GetMapping("/copy") 
	public String copyEmployee(@RequestParam("employeeId") int id)
	{
		Employee findEmployee = employeeService.findEmployee(id);
		
		Employee employee = new Employee(findEmployee.getFirstName(), findEmployee.getLastName(), findEmployee.getEmail());
		employee.setId(0);
		
		employeeService.saveEmployee(employee);
		
		return "redirect:/api/employees";
	}
}