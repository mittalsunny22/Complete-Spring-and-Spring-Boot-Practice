package com.springBoot.rest.crudSpringBootDemo.service;

import java.util.List;

import com.springBoot.rest.crudSpringBootDemo.Entity.Employee;

public interface EmployeeService {

	public List<Employee> findAll();
	
	public Employee findEmployee(int id);
	
	public void saveEmployee(Employee employee);
	
	public void deleteEmployee(int id);
}
